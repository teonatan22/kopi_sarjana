package com.example.kopisarjana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
