import 'package:flutter/material.dart';
import 'package:kopisarjana/widgets/custom_navbar.dart';

class VoucherPage extends StatelessWidget {
  final bool isLoggedIn;

  VoucherPage({required this.isLoggedIn});

  final List<Map<String, String>> vouchers = [
    {"title": "Nikmati diskon 20% untuk semua minuman dan makanan di Kopi Sarjana!", "date": "21 Nov 2024"},
    {"title": "Voucher Spesial: Beli 1 Gratis 1\nBeli satu minuman, dapatkan satu minuman gratis!", "date": "21 Nov 2024"},
    {"title": "Voucher Happy Hour\nDiskon 30% untuk semua minuman setiap hari dari jam 3 sore - 5 sore!", "date": "21 Nov 2024"},
    {"title": "Voucher Pendaftaran Member\nDaftar sebagai member dan dapatkan diskon 15% untuk setiap pembelian!", "date": "21 Nov 2024"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          "Voucher",
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Punya kode promo? Boleh masukkin sini yaa",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildVoucherTab("Voucher Belanja", true),
                SizedBox(width: 8),
                _buildVoucherTab("Voucher Delivery", false),
              ],
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: vouchers.length,
                itemBuilder: (context, index) {
                  final voucher = vouchers[index];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: _buildVoucherCard(voucher["title"]!, voucher["date"]!),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: 2,
        isLoggedIn: isLoggedIn,
      ),
    );
  }

  Widget _buildVoucherTab(String title, bool isSelected) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? Color(0xFFFFE4C8) : Color(0xFFFFE4C8),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: isSelected ? Colors.black : Colors.black54,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVoucherCard(String title, String date) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFFA67B5B),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 8),
                Text(
                  "Berlaku hingga $date",
                  style: TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          SizedBox(width: 16),
          ElevatedButton(
            onPressed: () {},
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text(
              "Pakai",
              style: TextStyle(color: Color(0xFFA67B5B), fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
