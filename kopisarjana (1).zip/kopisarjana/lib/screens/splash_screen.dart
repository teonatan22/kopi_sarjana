import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home.dart';
import 'login_screen.dart';

class SplashScreen extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<bool> checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isLoggedIn') ?? false;
  }

  Future<String?> getUsernameFromDatabase(String phoneNumber) async {
    try {
      QuerySnapshot result = await _firestore
          .collection('users')
          .where('phone_number', isEqualTo: phoneNumber)
          .get();

      if (result.docs.isNotEmpty) {
        return result.docs.first['username'];
      } else {
        return null;
      }
    } catch (e) {
      print("Error fetching username: $e");
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3), () async {
      bool isLoggedIn = await checkLoginStatus();

      if (isLoggedIn) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        String? phoneNumber = prefs.getString('phoneNumber');

        String? userName = await getUsernameFromDatabase(phoneNumber ?? "");

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => HomeScreen(
              isLoggedIn: true,
              userName: userName ?? "User",
            ),
          ),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => LoginScreen(),
          ),
        );
      }
    });

    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/image/Landing_Page.png',
              fit: BoxFit.cover,
            ),
          ),
        ],
      ),
    );
  }
}
