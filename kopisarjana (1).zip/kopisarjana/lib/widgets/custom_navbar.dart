import 'package:flutter/material.dart';
import 'package:kopisarjana/screens/account_screen.dart';
import 'package:kopisarjana/screens/history_order_screen.dart';
import 'package:kopisarjana/screens/voucher_screen.dart';
import 'package:kopisarjana/screens/notification_screen.dart';
import 'package:kopisarjana/screens/home.dart';

class CustomBottomNavigationBar extends StatelessWidget {
  final int currentIndex;
  final bool isLoggedIn;

  CustomBottomNavigationBar({
    required this.currentIndex,
    required this.isLoggedIn,
  });

  void _onItemTapped(BuildContext context, int index) {
    if (index == currentIndex) return;

    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => HomeScreen(isLoggedIn: isLoggedIn),
          ),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => OrderHistoryPage(isLoggedIn: isLoggedIn,),
          ),
        );
        break;
      case 2:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => VoucherPage(isLoggedIn: isLoggedIn,),
          ),
        );
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => NotificationPage(isLoggedIn: isLoggedIn,),
          ),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => AccountPage(isLoggedIn: isLoggedIn),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      selectedItemColor: Color(0xFFA67B5B),
      unselectedItemColor: Colors.grey,
      showUnselectedLabels: true,
      backgroundColor: Colors.white,
      onTap: (index) => _onItemTapped(context, index),
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
        BottomNavigationBarItem(icon: Icon(Icons.local_mall), label: "Order"),
        BottomNavigationBarItem(icon: Icon(Icons.tag), label: "Offer"),
        BottomNavigationBarItem(
            icon: Icon(Icons.notifications), label: "Notification"),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: "Account"),
      ],
    );
  }
}
