import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kopisarjana/utils/password_utils.dart';

class AuthService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Fungsi untuk registrasi pengguna
  Future<void> registerUser(String username, String phoneNumber, String password) async {
    try {
      // Cek apakah nomor telepon sudah digunakan
      QuerySnapshot result = await _firestore
          .collection('users')
          .where('phone_number', isEqualTo: phoneNumber)
          .get();

      if (result.docs.isNotEmpty) {
        throw Exception("Nomor telepon sudah terdaftar.");
      }

      // Hash password
      String hashedPassword = hashPassword(password);

      // Simpan data pengguna ke Firestore
      await _firestore.collection('users').add({
        'username': username,
        'phone_number': phoneNumber,
        'password': hashedPassword,
        'createdAt': FieldValue.serverTimestamp(), // Waktu pendaftaran
      });
    } catch (e) {
      throw Exception("Error registering user: $e");
    }
  }

  // Fungsi untuk login pengguna
  Future<bool> loginUser(String phoneNumber, String password) async {
    try {
      String hashedPassword = hashPassword(password);

      // Cari pengguna berdasarkan nomor telepon
      QuerySnapshot result = await _firestore
          .collection('users')
          .where('phone_number', isEqualTo: phoneNumber)
          .get();

      if (result.docs.isEmpty) {
        throw Exception("Pengguna tidak ditemukan.");
      }

      var user = result.docs.first;
      if (user['password'] == hashedPassword) {
        return true; // Login berhasil
      } else {
        throw Exception("Password salah.");
      }
    } catch (e) {
      throw Exception("Error logging in: $e");
    }
  }
}
