final List<Map<String, dynamic>> coffeeData = [
  {
    "name": "Cappuccino",
    "price": 26000,
    "image": "assets/image/cappuccino.png",
    "description": "Kelezatan espresso berpadu dengan buih susu yang lembut."
  },
  {
    "name": "Americano",
    "price": 19000,
    "image": "assets/image/americano.png",
    "description": "Rasa kopi hitam yang kuat untuk penyuka cita rasa orisinal."
  },
  {
    "name": "Caramel Macchiato",
    "price": 28000,
    "image": "assets/image/caramel_macchiato.png",
    "description": "Campuran espresso, susu, dan saus karamel yang lembut."
  },
  {
    "name": "Latte",
    "price": 25000,
    "image": "assets/image/latte.png",
    "description": "Espresso dan susu yang menyatu sempurna."
  },
  {
    "name": "Kopi Susu",
    "price": 18000,
    "image": "assets/image/kopi_susu.png",
    "description": "Kopi tradisional berpadu dengan susu lokal."
  },
  {
    "name": "Hazelnut",
    "price": 23000,
    "image": "assets/image/hazelnut.png",
    "description": "Rasa kacang hazelnut yang gurih dan lezat."
  },
  {
    "name": "Chocolate",
    "price": 22000,
    "image": "assets/image/chocolate.png",
    "description": "Minuman cokelat dengan rasa yang pekat dan manis."
  },
  {
    "name": "Milo",
    "price": 21000,
    "image": "assets/image/milo.png",
    "description": "Minuman cokelat malt yang disukai semua kalangan."
  },
];

final List<Map<String, dynamic>> nonCoffeeData = [
  {
    "name": "Lemon Tea",
    "price": 15000,
    "image": "assets/image/lemon_tea.png",
    "description": "Teh segar dengan sentuhan lemon yang menyegarkan."
  },
  {
    "name": "Teh Tarik",
    "price": 16000,
    "image": "assets/image/teh_tarik.png",
    "description": "Teh khas dengan rasa susu yang kental dan manis."
  },
  {
    "name": "Matcha",
    "price": 20000,
    "image": "assets/image/matcha.png",
    "description": "Minuman matcha dengan rasa asli Jepang."
  },
  {
    "name": "Air Mineral",
    "price": 8000,
    "image": "assets/image/air_mineral.png",
    "description": "Air mineral untuk melepas dahaga."
  },
  {
    "name": "Donat Gula Kampung",
    "price": 8000,
    "image": "assets/image/donat_gula.png",
    "description": "Donat tradisional yang manis dan empuk."
  },
  {
    "name": "Red Velvet Cupcake",
    "price": 10000,
    "image": "assets/image/red_velvet.png",
    "description": "Cupcake lembut dengan rasa red velvet."
  },
  {
    "name": "Bolu Pisang",
    "price": 9000,
    "image": "assets/image/bolu_pisang.png",
    "description": "Kue bolu pisang yang manis dan harum."
  },
];
