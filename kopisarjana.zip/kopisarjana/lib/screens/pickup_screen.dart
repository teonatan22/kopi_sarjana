import 'package:flutter/material.dart';

class PickupScreen extends StatefulWidget {
  @override
  _PickupScreenState createState() => _PickupScreenState();
}

class _PickupScreenState extends State<PickupScreen> {
  final List<Map<String, dynamic>> products = [
    {"name": "Cappucino", "price": 26000, "image": 'assets/image/cappuccino.png', "isFavorite": false, "quantity": 0},
    {"name": "Americano", "price": 19000, "image": 'assets/image/americano.png', "isFavorite": false, "quantity": 0},
  ];

  int totalPrice = 0;

  void toggleFavorite(int index) {
    setState(() {
      products[index]["isFavorite"] = !products[index]["isFavorite"];
    });
  }

  void addToCart(int index) {
    setState(() {
      products[index]["quantity"]++;
      calculateTotal();
    });
  }

  void calculateTotal() {
    totalPrice = products.fold(0, (sum, item) => sum + (item["quantity"] * item["price"] as int));
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pick Up"),
        backgroundColor: Color(0xFFFED8B1),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Color(0xFFFED8B1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.location_on, color: Colors.brown),
                        SizedBox(width: 8),
                        Text(
                          "Kisamaun",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    Icon(Icons.arrow_forward_ios, color: Colors.brown),
                  ],
                ),
              ),
              SizedBox(height: 16),
              // Tabs
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildTab("Buddies Fav", true),
                  _buildTab("Coffee", false),
                  _buildTab("Non Coffee", false),
                ],
              ),
              SizedBox(height: 16),
              // Section Title
              Text(
                "Buddies Fav!",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              // Product List
              ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: products.length,
                itemBuilder: (context, index) {
                  final product = products[index];
                  return _buildProductItem(
                    product: product,
                    onFavorite: () => toggleFavorite(index),
                    onAdd: () => addToCart(index),
                  );
                },
              ),
              SizedBox(height: 16),
              // Total Price
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Total: Rp$totalPrice",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Handle checkout
                    },
                    child: Text("Checkout"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFFA67B5B),
                      padding: EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTab(String label, bool isSelected) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      decoration: BoxDecoration(
        color: isSelected ? Colors.brown : Colors.transparent,
        border: Border.all(color: Colors.brown),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: isSelected ? Colors.white : Colors.brown,
        ),
      ),
    );
  }

  Widget _buildProductItem({
    required Map<String, dynamic> product,
    required VoidCallback onFavorite,
    required VoidCallback onAdd,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.brown),
      ),
      child: Row(
        children: [
          Image.asset(
            product["image"],
            height: 60,
            width: 60,
            fit: BoxFit.cover,
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product["name"],
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Text(
                  "Rp ${product["price"]}",
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          IconButton(
            icon: Icon(
              product["isFavorite"] ? Icons.favorite : Icons.favorite_border,
              color: Colors.red,
            ),
            onPressed: onFavorite,
          ),
          IconButton(
            icon: Icon(Icons.add_circle, color: Colors.green),
            onPressed: onAdd,
          ),
        ],
      ),
    );
  }
}
