import 'package:flutter/material.dart';
import 'package:kopisarjana/screens/ReferalCodeScreen.dart';
import 'package:kopisarjana/screens/delivery_screen.dart';
import 'package:kopisarjana/screens/gift_screen.dart';
import 'package:kopisarjana/screens/pickup_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:kopisarjana/widgets/custom_navbar.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isLoggedIn;
  final String? userName;

  HomeScreen({required this.isLoggedIn, this.userName});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final PageController _pageController = PageController(initialPage: 0);
  int _currentPage = 0;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            Column(
              children: [
                // Slider
                ClipRRect(
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(60),
                    bottomRight: Radius.circular(60),
                  ),
                  child: SizedBox(
                    height: 260,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        PageView(
                          controller: _pageController,
                          onPageChanged: (index) {
                            setState(() {
                              _currentPage = index;
                            });
                          },
                          children: [
                            Image.asset(
                              'assets/image/ads/ads-1.png',
                              fit: BoxFit.cover,
                            ),
                            Image.asset(
                              'assets/image/ads/ads-2.png',
                              fit: BoxFit.cover,
                            ),
                            Image.asset(
                              'assets/image/ads/ads-3.png',
                              fit: BoxFit.cover,
                            ),
                            Image.asset(
                              'assets/image/ads/ads-4.png',
                              fit: BoxFit.cover,
                            ),
                          ],
                        ),
                        Positioned(
                          bottom: 16,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: List.generate(
                              4,
                                  (index) => Container(
                                margin: EdgeInsets.symmetric(horizontal: 4),
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: _currentPage == index
                                      ? Color(0xFFA67B5B)
                                      : Colors.grey[300],
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 16),
                // Welcome Section
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 50),
                      Text(
                        "Want to order now?",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildActionButton(
                            label: "Pick Up",
                            icon: Icons.coffee,
                            backgroundColor: Color(0xFFFED8B1),
                            borderColor: Color(0xFFA67B5B),
                            textColor: Colors.black,
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => PickupScreen(),
                                ),
                              );
                            },
                          ),
                          _buildActionButton(
                            label: "Delivery",
                            icon: Icons.delivery_dining,
                            backgroundColor: Color(0xFFA67B5B),
                            borderColor: Color(0xFFFFA243),
                            textColor: Colors.white,
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DeliveryScreen(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 16),
                      Text(
                        "Share ur Happines!",
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildActionButton(
                            label: "Share Kode-mu",
                            icon: Icons.share,
                            backgroundColor: Color(0xFFA67B5B),
                            borderColor: Color(0xFFFFA243),
                            textColor: Colors.white,
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => ReferralCodeScreen(referralCode: "002345"),
                                ),
                              );
                            },
                          ),
                          _buildActionButton(
                            label: "Gift Your Buddy!",
                            icon: Icons.card_giftcard,
                            backgroundColor: Color(0xFFA67B5B),
                            borderColor: Color(0xFFFFA243),
                            textColor: Colors.white,
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => GiftPage(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Text(
                        "Need a help?",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center, // Pusatkan seluruh baris
                        children: [
                          Container(
                            padding: EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: FaIcon(
                              FontAwesomeIcons.whatsapp,
                              color: Colors.green,
                              size: 28,
                            ),
                          ),
                          SizedBox(width: 16),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 8.0), // Tambahkan padding vertikal
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start, // Tetap rata kiri dalam kolom
                              children: [
                                Text(
                                  "Your buddies, here! (chat only)",
                                  style: TextStyle(
                                    fontSize: 14,
                                    color: Colors.grey[700],
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  "+62 834 - 222 - 111",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFFA67B5B),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Positioned(
              top: 220,
              left: MediaQuery.of(context).size.width * 0.1,
              right: MediaQuery.of(context).size.width * 0.1,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 6,
                      spreadRadius: 2,
                    ),
                  ],
                  border: Border.all(color: Colors.grey.shade300),
                ),
                padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                child: Center(
                  child: Text(
                    "Hello, ${widget.userName ?? "User"}!\nLet’s grab ur Coffee now!",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      height: 1.4,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: 0,
        isLoggedIn: widget.isLoggedIn,
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required Color backgroundColor,
    required Color borderColor,
    required Color textColor,
    required VoidCallback onPressed,
  }) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8),
        child: ElevatedButton.icon(
          onPressed: onPressed,
          icon: Icon(icon, color: textColor),
          label: Text(label, style: TextStyle(color: textColor)),
          style: ElevatedButton.styleFrom(
            backgroundColor: backgroundColor,
            side: BorderSide(color: borderColor, width: 2),
            padding: EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ),
    );
  }
}
