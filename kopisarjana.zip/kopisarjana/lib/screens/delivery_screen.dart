import 'package:flutter/material.dart';
import 'package:kopisarjana/model/menu_data.dart';

class DeliveryScreen extends StatefulWidget {
  @override
  _DeliveryScreenState createState() => _DeliveryScreenState();
}

class _DeliveryScreenState extends State<DeliveryScreen> {
  final List<Map<String, dynamic>> cart = [];
  final List<String> favorites = [];

  int get totalPrice => cart.fold<int>(
      0, (sum, item) => sum + (item["price"] as int) * (item["quantity"] as int));

  int get totalItems =>
      cart.fold<int>(0, (sum, item) => sum + (item["quantity"] as int));

  void addToCart(Map<String, dynamic> product) {
    setState(() {
      final index = cart.indexWhere((item) => item["name"] == product["name"]);
      if (index >= 0) {
        cart[index]["quantity"] += 1;
      } else {
        cart.add({"name": product["name"], "price": product["price"], "quantity": 1});
      }
    });
  }

  void removeFromCart(Map<String, dynamic> product) {
    setState(() {
      final index = cart.indexWhere((item) => item["name"] == product["name"]);
      if (index >= 0 && cart[index]["quantity"] > 0) {
        cart[index]["quantity"] -= 1;
        if (cart[index]["quantity"] == 0) {
          cart.removeAt(index);
        }
      }
    });
  }

  int getQuantity(String productName) {
    final index = cart.indexWhere((item) => item["name"] == productName);
    if (index >= 0) {
      return cart[index]["quantity"];
    }
    return 0;
  }

  void toggleFavorite(String productName) {
    setState(() {
      if (favorites.contains(productName)) {
        favorites.remove(productName);
      } else {
        favorites.add(productName);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildAddressSection(),
                SizedBox(height: 16),
                _buildCategories(),
                SizedBox(height: 16),
                Text(
                  "Buddies Fav!",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16),
                SizedBox(
                  height: 200,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: coffeeData.take(3).map((product) {
                      return _buildFavoriteProductItem(product);
                    }).toList(),
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  "Coffee",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16),
                ...coffeeData.map((product) => _buildVerticalProductItem(product)),
                SizedBox(height: 16),
                Text(
                  "Non Coffee",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 16),
                ...nonCoffeeData.map((product) => _buildVerticalProductItem(product)),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: _buildCartBar(),
    );
  }

  Widget _buildAddressSection() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 6,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          _buildAddressRow("Kisamaun", "2 km dari kamu"),
          Divider(color: Colors.grey.shade400),
          _buildAddressRow("Rumahku, Surgaku", "Alamat tersimpan"),
        ],
      ),
    );
  }

  Widget _buildAddressRow(String title, String subtitle) {
    return Row(
      children: [
        Icon(Icons.location_pin, color: Colors.orange, size: 24),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                subtitle,
                style: TextStyle(color: Colors.grey[600]),
              ),
            ],
          ),
        ),
        Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
      ],
    );
  }

  Widget _buildCategories() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildCategoryButton("Buddies Fav", true),
        SizedBox(width: 8),
        _buildCategoryButton("Coffee", false),
        SizedBox(width: 8),
        _buildCategoryButton("Non Coffee", false),
      ],
    );
  }

  Widget _buildCategoryButton(String label, bool isSelected) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        backgroundColor: isSelected ? Color(0xFFA67B5B) : Colors.white,
        side: BorderSide(color: Color(0xFFA67B5B)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      onPressed: () {},
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Color(0xFFA67B5B),
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildFavoriteProductItem(Map<String, dynamic> product) {
    final isFavorite = favorites.contains(product["name"]);
    final quantity = getQuantity(product["name"]);

    return Card(
      color: Colors.white,
      margin: EdgeInsets.symmetric(horizontal: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Container(
        width: 160,
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Stack(
              children: [
                Image.asset(
                  product["image"],
                  height: 80,
                  fit: BoxFit.cover,
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child: IconButton(
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? Colors.red : Colors.black12,
                    ),
                    onPressed: () => toggleFavorite(product["name"]),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              product["name"],
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4),
            Text(
              "Rp ${product["price"]}",
              style: TextStyle(color: Colors.grey[600]),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (quantity > 0)
                  IconButton(
                    icon: Icon(Icons.remove_circle, color: Colors.orange),
                    onPressed: () => removeFromCart(product),
                  ),
                if (quantity > 0)
                  Text(
                    "$quantity",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                IconButton(
                  icon: Icon(Icons.add_circle, color: Colors.orange),
                  onPressed: () => addToCart(product),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVerticalProductItem(Map<String, dynamic> product) {
    final isFavorite = favorites.contains(product["name"]);
    final quantity = getQuantity(product["name"]);

    return Card(
      color: Colors.white,
      margin: EdgeInsets.symmetric(vertical: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: Image.asset(
          product["image"],
          width: 40,
          height: 40,
          fit: BoxFit.cover,
        ),
        title: Text(product["name"], style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("Rp ${product["price"]}", style: TextStyle(color: Colors.grey)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(
                isFavorite ? Icons.favorite : Icons.favorite_border,
                color: isFavorite ? Colors.red : Colors.grey,
              ),
              onPressed: () => toggleFavorite(product["name"]),
            ),
            Row(
              children: [
                if (quantity > 0)
                  IconButton(
                    icon: Icon(Icons.remove_circle, color: Colors.orange),
                    onPressed: () => removeFromCart(product),
                  ),
                if (quantity > 0)
                  Text("$quantity", style: TextStyle(fontWeight: FontWeight.bold)),
                IconButton(
                  icon: Icon(Icons.add_circle, color: Colors.orange),
                  onPressed: () => addToCart(product),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCartBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Color(0xFFA67B5B),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Cek Keranjang ($totalItems Produk) Rp $totalPrice",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          IconButton(
            icon: Icon(Icons.shopping_basket, color: Colors.white),
            onPressed: () {
              // Tambahkan logika untuk navigasi ke halaman keranjang
            },
          ),
        ],
      ),
    );
  }
}
