import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'home.dart';
import 'register_screen.dart';
import 'package:kopisarjana/services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController pinController = TextEditingController();
  bool isPinObscured = true;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> saveLoginStatus(String phoneNumber, String userName) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool('isLoggedIn', true);
    prefs.setString('phoneNumber', phoneNumber);
    prefs.setString('userName', userName);
  }

  Future<String?> getUsernameFromFirestore(String phoneNumber) async {
    try {
      QuerySnapshot result = await _firestore
          .collection('users')
          .where('phone_number', isEqualTo: phoneNumber)
          .get();

      if (result.docs.isNotEmpty) {
        return result.docs.first['username'];
      } else {
        return null;
      }
    } catch (e) {
      print("Error fetching username: $e");
      return null;
    }
  }

  void login(BuildContext context) async {
    String phone = phoneController.text.trim();
    String pin = pinController.text.trim();

    if (phone.isEmpty || pin.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Nomor handphone dan Password harus diisi")),
      );
      return;
    }

    try {
      bool success = await AuthService().loginUser(phone, pin);
      if (success) {
        String? userName = await getUsernameFromFirestore(phone);

        if (userName != null) {
          await saveLoginStatus(phone, userName);

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Login berhasil!")),
          );

          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => HomeScreen(
                isLoggedIn: true,
                userName: userName,
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Nama pengguna tidak ditemukan.")),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Login gagal. Periksa kembali data Anda.")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.toString())),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true, // Menghindari masalah bottom overflow
      body: SingleChildScrollView( // Membuat halaman bisa di-scroll
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 60), // Tambahkan spasi di atas
              // Logo dan nama aplikasi
              Column(
                children: [
                  Image.asset(
                    'assets/image/background-login.png',
                    height: 300,
                  ),
                  const SizedBox(height: 10),
                ],
              ),
              const SizedBox(height: 40),
              // Input Nomor Handphone
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: "Masukkan Nomor Handphone",
                  labelStyle: TextStyle(color: Colors.white),
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  filled: true,
                  fillColor: Color(0xFFA67B5B),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFA243)),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFA243), width: 2),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  prefixIcon: Icon(Icons.phone, color: Colors.white),
                ),
              ),
              const SizedBox(height: 20),
              // Input Password
              TextField(
                controller: pinController,
                obscureText: isPinObscured,
                keyboardType: TextInputType.text,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: "Masukkan Password",
                  labelStyle: TextStyle(color: Colors.white),
                  filled: true,
                  fillColor: Color(0xFFA67B5B),
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFA243)),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xFFFFA243), width: 2),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  prefixIcon: Icon(Icons.lock, color: Colors.white),
                  suffixIcon: IconButton(
                    icon: Icon(
                      isPinObscured ? Icons.visibility : Icons.visibility_off,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      setState(() {
                        isPinObscured = !isPinObscured;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () {
                    // Aksi jika Password lupa
                  },
                  child: const Text(
                    "Forgot Password?",
                    style: TextStyle(color: Colors.orange),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Tombol Login
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFFFFA243),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  onPressed: () => login(context),
                  child: const Text(
                    "Login",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.bold, // Bold untuk teks Login
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Tombol Sign In
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RegisterScreen()),
                  );
                },
                child: const Text(
                  "Sign Up",
                  style: TextStyle(
                    color: Colors.orange,
                    fontWeight: FontWeight.bold, // Bold untuk teks Sign in
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
