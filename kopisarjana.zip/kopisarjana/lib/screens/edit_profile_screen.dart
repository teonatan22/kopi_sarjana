import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:kopisarjana/widgets/custom_navbar.dart';

class EditProfilePage extends StatelessWidget {
  final bool isLoggedIn;

  EditProfilePage({required this.isLoggedIn});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text(
          "My Account",
          style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(height: 16),
            // Member Info
            Container(
              padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              decoration: BoxDecoration(
                color: Color(0xFFA67B5B),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                "Member sejak: 26 September 2023",
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
            ),
            SizedBox(height: 24),
            // Profile Picture
            CircleAvatar(
              radius: 50,
              backgroundImage: AssetImage('assets/image/profile.png'),
            ),
            SizedBox(height: 16),
            // Instructions
            Text(
              "Lengkapi data dirimu yuk, siapa tahu kamu bisa dapatkan voucher menarik di hari spesialmu",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey[700]),
            ),
            SizedBox(height: 24),
            // Profile Data Fields
            _buildProfileField("Username", "ANIN"),
            _buildProfileField("Email", "anindymp@gmail.com"),
            _buildProfileField("Tanggal Lahir", ""),
            _buildProfileField("Jenis Kelamin", ""),
            _buildProfileField("Nomor Handphone", ""),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: 4,
        isLoggedIn: isLoggedIn,
      ),
    );
  }

  Widget _buildProfileField(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey[700]),
          ),
          SizedBox(height: 8),
          TextField(
            decoration: InputDecoration(
              hintText: value,
              contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
