import 'package:flutter/material.dart';
import 'package:kopisarjana/widgets/custom_navbar.dart';

class NotificationPage extends StatelessWidget {
  final bool isLoggedIn;

  NotificationPage({required this.isLoggedIn});

  final List<String> notifications = [
    "Daftar sebagai member dan nikmati diskon 15% untuk setiap pembelian!",
    "Dapatkan diskon 20% untuk semua minuman dan makanan mulai hari ini hingga 20 Nov 2024! Tunjukkan voucher ini saat pembayaran. Jangan lewatkan kesempatan ini!",
    "☕ Happy Hour Alert! Nikmati diskon 30% untuk semua minuman setiap hari dari jam 3 sore hingga 5 sore di Kopi Sarjana! Segera kunjungi kami dan nikmati waktu santai Anda!",
    "Rayakan ulang tahun Anda bersama kami! Dapatkan minuman gratis pada hari ulang tahun Anda dengan menunjukkan identitas diri yang valid. Selamat merayakan!",
    "Kami ingin mengucapkan terima kasih atas dukungan Anda! Jangan lupa untuk mengikuti kami di media sosial untuk mendapatkan update promo dan acara terbaru.",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.orange),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          "Inbox",
          style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: notifications.length,
        itemBuilder: (context, index) {
          return Container(
            padding: EdgeInsets.all(16),
            margin: EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: Color(0xFFFFE4C8),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              notifications[index],
              style: TextStyle(fontSize: 14, color: Colors.black),
            ),
          );
        },
      ),
      bottomNavigationBar: CustomBottomNavigationBar(
        currentIndex: 3,
        isLoggedIn: isLoggedIn,
      ),
    );
  }
}
